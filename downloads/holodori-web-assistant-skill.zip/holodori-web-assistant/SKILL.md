---
name: holodori-web-assistant
description: Use an open HolodoriCalc browser tab to calculate team scores, interpret results, and compare growth scenarios through browser controls or available site tools.
---

# HolodoriCalc web assistant

Let the website perform all calculations. This skill supplies instructions only: no engine, card/chart database, executable scripts, or calculation server. Answer in Korean unless the user requests another language.

## Connect

Use the user's existing calculator tab in the browser profile where they normally use the calculator, including Edge with the official ChatGPT browser extension. The extension connects to the desktop app and can open side chat from its toolbar icon. Data saved in that browser profile is used directly; do not ask the user to move it to the built-in browser. Respect a supplied localhost or other calculator URL. If no tab is available, open https://doricalc-holo.live/ in that connected browser. If browser control itself is unavailable, explain the required desktop-app/browser connection; reading this guide does not provide that capability. Do not promise ordinary ChatGPT web/mobile support.

For Windows setup guidance, point to the [official ChatGPT Windows installer](https://get.microsoft.com/installer/download/9PLM9XGG6VKS?cid=website_cta_psi), then have the user open the app and sign in. The [official browser extension](https://chromewebstore.google.com/detail/chatgpt/hehggadaopoacecdllhhajmbjkdcmajg?hl=ko) is installed in their usual calculator browser profile. The desktop app's **Settings → Computer Use** shows the browser connection; see the [official connection instructions](https://learn.chatgpt.com/docs/chrome-extension) if setup is incomplete. Do not install software merely to answer a calculator analysis request.

Choose the available route:

- **Browser controls:** Read [references/browser-workflow.md](references/browser-workflow.md) before operating the calculator. This route uses the existing calculation screens and needs no AI connection switch. An unavailable WebMCP capability or disabled **이 탭에서 AI 연결 켜기** switch does not prevent screen interaction. Do not repeatedly attempt an unsupported connection.
- **Site tools:** Prefer them only when the browser advertises WebMCP and the page already exposes the relevant tools. The current **도구 → AI 연결** page provides browser setup guidance and an AI usage guide, not a tool connection switch. If tools are absent, use browser controls. Discover actual names and schemas; expected names are `holodori_context`, `holodori_catalog`, and `holodori_analyze`, possibly with host-added suffixes. Read [references/requests.md](references/requests.md) for this route only.

Use data saved in that browser. If required owned/growth data is missing, explain what is missing and guide the user to **사용자 데이터** or their calculator backup. Do not assume all cards are owned, migrate unrelated browser data automatically, ask for Node installation, or run the previous bundled plugin in cloud code execution.

## Calculate and compare

- Keep the user's requested song, difficulty, team, leader/outfit, and goal. If the request says "현재 편성", start from the visible conditions. Distinguish **예상 점수** (expected/average) from theoretical maximum. Default to owned cards and expected score when the goal is unspecified, while respecting the website's actual optimization goal.
- Read a completed baseline, change only the requested scenario, calculate again, and compare scores using the same remaining conditions. Growth changes can affect parameters and skills; do not estimate score changes from power alone. Delta = scenario minus baseline; relative change uses baseline as denominator.
- Browser route: record original conditions, use analysis-only inputs, verify each changed value before calculating, and restore changed conditions after comparison. Recalculate the restored baseline to verify the result. Inputs may persist automatically even without a save button.
- Tool route: start with `holodori_context`; resolve IDs through `holodori_catalog` rather than inventing them. Use `holodori_analyze` and `scenario`, with the first team as baseline. Require `status: complete` before reporting scores.
- Never edit **사용자 데이터** ownership/growth, board layouts, presets, or saved analysis records merely to model a scenario. Apply or save results only when the user requests it. On failure, restore any changed analysis inputs and state which result or restoration remains unverified.
- Reuse completed results that answer follow-up questions. Keep additional experiments focused on the user's question instead of automatically running every possible team or growth stage.

## Explain the result

Report the song/difficulty, team and relevant leader/outfit, expected score, maximum score, changed assumption, and delta. State whether each scenario was separately reoptimized; do not describe that as a comparison with the same special order/frequency allocation held fixed. Mention important overrides and any displayed score-calibration warning. **빈도 조합 상위** in **배치 분석** is ordered by maximum score: its first row is not necessarily the best average. An expected-score comparison of visible rows is limited to those rows, not all possible combinations.

The displayed probabilities assume all notes are PERFECT and vary only active-skill activation; report exact versus sampled probabilities as labeled by the current page/result. Search narrows candidates and does not prove global optimality. For site-tool multi-chart rankings, scores are optimized separately for each chart, not a shared fixed order. Do not invent event bonuses or unavailable charts.

Browser results appear on their calculation screen; explain available site-tool results from their returned data. The user's analysis request does not authorize sharing collection data with unrelated services or changing saved user data.
