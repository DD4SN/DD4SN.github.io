# Browser calculation workflow

Use the host's documented browser controls and current visible labels. The labels below describe the calculator; inspect the live page rather than assuming control coordinates, option IDs, or browser APIs. Keep the user's tab open.

## Find the appropriate screen

- **배치 분석**: score an existing five-card team, optimize special-skill order and frequency reductions, and compare individual card awakening scenarios.
- **조합 탐색**: search team candidates under the visible fixed-card and ownership conditions. Read the screen's stated optimization objective; ordinary search optimizes maximum score, not necessarily average score.
- **사용자 데이터**: inspect saved ownership, memory count, member upgrades, and growth when needed. Do not change these for hypothetical calculations.
- **도구 → AI 연결**: browser setup guidance and a link to the AI usage guide. Read the guide in its separate tab and operate the original calculator tab. Use the ordinary analysis screens for calculation; this page has no tool connection switch or result panel.

Use the visible navigation. Preserve the current origin and URL style: online Pages may use hash routes while other deployments use path routes.

## Baseline on 배치 분석

1. Read **분석 조건**. Record the song, difficulty, five selected cards with their slot numbers and awakenings, **리더**, **리더 의상**, frequency locks, **파란 노드 전체** checkboxes, generation overrides, and song-score override. Also note visible memory/member-upgrade context when explaining a comparison.
2. Cards are five-star cards from five different members. A leading **●** in a card option means owned. A member name alone may identify multiple variants; use the complete displayed card name. The selected awakening is an analysis assumption and may differ from saved ownership growth. **명함** means 0 awakening; maximum is 5. The page calculates parameters at maximum card level.
3. Use **최적 배치 분석** and observe progress. While **분석 중 …%** is displayed, do not interpret a previous result as the new calculation. A short browser wait timing out does not mean the calculation failed: read progress before retrying, and do not start duplicate jobs.
4. Verify completion with the ready calculation button, no running progress/error, and a populated **분석 결과** for the chosen song/difficulty and analysis power. If **입력 조건 또는 사용자 데이터가 변경되었습니다** is shown, the displayed result is stale; require a fresh calculation until the warning disappears. After a scenario change, require a new completed calculation even when its score happens to equal the baseline.
5. Read the concise result summary rather than the entire skill timeline: **예상 점수**, **최고점 · 밀어치기 적용**, **최고점 · 밀어치기 미적용**, **추천 스페셜 발동 순서**, and per-card **쿨타임 …% 감소**. Record the selected frequency row if relevant. A result can remain visible while inputs change: **분석 당시 종합력** belongs to the completed run; **자동 계산 종합력** belongs to current inputs.

## Growth comparison and restoration

For "현재 편성에서 코보를 명함으로 가정하면?" find Kobo's actual selected slot; do not assume a fixed slot across users. Record its original awakening and completed baseline. Use that slot's **N번 카드 개화 단계 낮추기/높이기** buttons until the adjacent numeric value is the requested stage, then read the updated input state before starting calculation. Hold every other condition constant. Read the newly completed scenario result, compute its difference from the baseline, restore the original stage, and calculate once more to verify restoration. Do not change Kobo's ownership record in **사용자 데이터**.

Each **최적 배치 분석** run optimizes special order/frequency allocations for that scenario. Report growth deltas as separately reoptimized outcomes. If the user asks to keep the exact order/allocation fixed, first verify that the available controls or tools support it; do not claim an optimized run holds them fixed.

Use the same approach for another card or outfit comparison. If changing a card alters dependent leader/outfit options, record and restore those too. On an interrupted or failed calculation, restore changed inputs when browser control remains available; otherwise tell the user which condition still needs restoration. Do not save/delete analysis records or presets during a comparison.

## Input meanings that affect conclusions

- **빈도 감소 고정** uses **미사용**, 0%, 4%, 8%, 12%. **미사용** leaves the reduction available for optimization; it does not fix it to 0%. These are optimization variables and are not unlocked solely by the saved blue-board state.
- **파란 노드 전체** is a hypothetical full-blue-board condition. Leave it off for the user's actual saved board unless that scenario was requested.
- A blank **기수 보너스 덮어쓰기 (0~900)** or **가창 보너스 덮어쓰기 (0~10%)** uses the actual board value. Entering 0 explicitly overrides it to zero. Preserve blanks versus numeric zeros.
- **리더 의상** affects team power; selecting a leader alone does not determine the full condition. Read the displayed costume effect.
- **최고점 · 밀어치기 적용** assumes relevant manually judged notes at a special-skill start boundary benefit from the new special effect. **밀어치기 미적용** excludes that boundary handling. Keep the same maximum-score definition when comparing runs.
- **예상 점수** incorporates active-skill randomness under the calculation's PERFECT-note assumption. It does not predict a player's actual accuracy.
- **빈도 조합 상위** is sorted by maximum score. The displayed average and success probabilities can favor another row. Select a row if its detailed result is needed, and distinguish "best among the displayed rows" from a global optimum.
- Probability labels and sample counts belong to the current page. Do not apply site-tool sample limits to screen calculations. Board/connection recommendations are separate operations; do not apply a recommended board layout as part of ordinary score comparison.

## Team search

On **조합 탐색**, record the visible search conditions before changing them. For owned-only requests, use **내가 보유한 카드만 사용하기**. Record fixed cards/awakenings, leader/outfit, candidate awakening, probability restrictions, overrides, and output count. The page explains how higher saved awakenings override lower automatic-candidate stages; read that guidance before treating every candidate as having the chosen stage.

Run **최적 조합 탐색** and wait through candidate screening, detailed analysis, and probability phases. Summarize the completed visible candidates and their assumptions. For a request to maximize average score, explain an available screen's maximum-score objective; use an advertised expected-score site tool if available, or compare a bounded set of candidates and state the search limitation. Restore search inputs changed for a temporary comparison.

## Continuing the conversation

Keep a compact baseline/scenario comparison in the conversation, including assumptions and values, so questions about existing results do not require another run. For a new experiment, read current page inputs again; the user may have changed them. If a requested growth scenario cannot be modeled by analysis inputs, explain that limitation instead of changing saved growth or making up a numerical result.
