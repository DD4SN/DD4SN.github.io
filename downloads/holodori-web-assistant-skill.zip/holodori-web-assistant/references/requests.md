# Analysis requests

These illustrate request structure. Replace every angle-bracket placeholder with an ID returned by the current page's catalog; they are not executable examples. Use the live tool schema if it differs.

## Bounded search

```json
{
  "schemaVersion": 1,
  "operation": "search",
  "charts": [{"songId": "<song-id>", "difficulty": "easy"}],
  "objective": "expected",
  "ownedOnly": true,
  "search": {
    "fixedCardIds": ["<required-card-id>"],
    "leaderCharacterId": "<member-id>",
    "leaderOutfitCardId": "<owned-outfit-card-id>",
    "maxTeams": 4
  }
}
```

Omit candidateCardIds to use owned five-star cards. If more than 200 are eligible, use catalog queries to narrow them. Fixed cards must be included in an explicitly supplied candidate pool. The leader defaults to the first team member; specifying a leader and owned outfit makes the intended comparison clear.

## Compare awakening

```json
{
  "schemaVersion": 1,
  "operation": "compare",
  "charts": [{"songId": "<song-id>", "difficulty": "easy"}],
  "teams": [
    {"name": "현재", "cardIds": ["<c1>", "<c2>", "<c3>", "<c4>", "<c5>"], "leaderCharacterId": "<member-id>", "leaderOutfitCardId": "<outfit-card-id>"},
    {"name": "4개화 가정", "cardIds": ["<c1>", "<c2>", "<c3>", "<c4>", "<c5>"], "leaderCharacterId": "<member-id>", "leaderOutfitCardId": "<outfit-card-id>", "scenario": {"awakeningByCardId": {"<c1>": 4}}}
  ]
}
```

Each team needs five five-star cards from different members. Limits: three charts, eight teams, beamWidth ≤64, probabilitySamples ≤5000, one active job, 30 seconds. Returned assumptions and provenance explain the calculation's scope. `memberBoards` and `boardCards` scenarios replace complete mappings; do not fabricate node/socket IDs when catalog/context information is insufficient.
